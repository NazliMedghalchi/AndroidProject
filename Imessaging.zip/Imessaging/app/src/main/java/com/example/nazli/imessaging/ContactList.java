package com.example.nazli.imessaging;

import android.app.Activity;

/**
 * Created by nazlimedghalchi on 2015-11-05.
 */
public class ContactList extends Activity {

}
