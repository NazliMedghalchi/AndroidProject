package com.example.nazli.imessaging;

        import android.app.Activity;
        import android.app.ListFragment;
        import android.database.Cursor;
        import android.provider.ContactsContract;
        import android.widget.ListView;

/**
 * Created by nazlimedghalchi on 2015-11-03.
 */
