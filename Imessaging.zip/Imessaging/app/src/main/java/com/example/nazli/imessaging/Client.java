package com.example.nazli.imessaging;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.webkit.ClientCertRequest;

/**
 * Created by nazlimedghalchi on 2015-11-04.
 */
public abstract class Client extends BroadcastReceiver {

    Context smsContext;
    private String netStatus = Application.NETWORK_STATS_SERVICE;

    @Override
    public void OnReceive () {

    }
//    private EditText title = (EditText) R

}
