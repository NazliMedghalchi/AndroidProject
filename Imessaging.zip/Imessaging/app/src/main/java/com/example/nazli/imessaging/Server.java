package com.example.nazli.imessaging;

import android.content.BroadcastReceiver;
import android.content.ServiceConnection;

import java.net.Socket;

/**
 * Created by nazlimedghalchi on 2015-11-04.
 */
public abstract class Server extends BroadcastReceiver{
//    Socket socket = new Socket("1.1.1.1", 1111);
    public void connectToServer(){

    }

}
