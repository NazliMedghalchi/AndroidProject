package com.example.nazli.imessaging;

import android.app.Application;
import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.view.View;
import android.widget.EditText;
import android.os.Bundle;

/**
 * Created by nazlimedghalchi on 2015-11-03.
 */
public abstract class ChatService extends Fragment {

    @Override
    public View onCreateView() {


    }

}
